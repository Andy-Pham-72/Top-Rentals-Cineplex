class RetrieveRental:
    '''
    Class Rental to store "title", "year", "synopsis" data
    '''
    def __init__(self, title, year, synopsis):
        """
        :param title: 
        :param year:
        :param synopsis:

        :return:
        """
        self.title = title
        self.year = year
        self.synopsis = synopsis