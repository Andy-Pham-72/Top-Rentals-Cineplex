class RetrieveRental:
    '''
    Class Rental to store "title", "year" data
    '''
    def __init__(self, title, year):
        """
        :param title: 
        :param year:

        :return:
        """
        self.title = title
        self.year = year