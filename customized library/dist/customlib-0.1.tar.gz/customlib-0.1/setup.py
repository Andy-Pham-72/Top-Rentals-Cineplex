import setuptools

setuptools.setup (
    name = "customlib",
    version = "0.1",
    packages = setuptools.find_packages(),
    # metadata for upload to PyPI
    author = "Andy Pham",
    author_email = "aqpham02@gmail.com",
    description = "This is a configuration directory Package",
    url="",
    classifiers = ["Programming Language :: Python :: 3",
            "License :: OSI Approved :: MIT License",
            "Operating System :: OS Independent"],
    python_requires = '>=3.6'
)